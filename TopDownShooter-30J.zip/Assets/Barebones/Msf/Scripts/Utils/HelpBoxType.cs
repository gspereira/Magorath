﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum HelpBoxType
{
    None,
    Info,
    Warning,
    Error
}
