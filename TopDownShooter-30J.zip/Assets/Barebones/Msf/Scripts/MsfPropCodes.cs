﻿namespace Barebones.MasterServer
{
    public enum MsfPropCodes : short
    {
        Start = 32000,

        // Rooms
        RegisteredRooms,

        // Spawners
        RegisteredSpawners,
        ClientSpawnRequest,
        
    }
}