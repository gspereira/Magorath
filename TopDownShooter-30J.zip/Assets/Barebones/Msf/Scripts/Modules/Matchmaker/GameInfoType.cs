﻿namespace Barebones.MasterServer
{
    public enum GameInfoType
    {
        Unknown,
        Room,
        Lobby
    }
}