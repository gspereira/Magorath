Thank you for purchasing Master Server Framework.

WARNING: It's highly adviced that you don't change scripts that come with the asset,
because your changes might be overriden when you update.
Instead, you should extend classes and use events to get the result that you need. If that's
impossible, contact me, and I'll resolve the issue by giving you an update or a small patch.

For documentation, you should use Wiki page on GitHub:
https://github.com/alvyxaz/barebones-masterserver/wiki

Feature and improvement requests, issues and bug reports should be posted at:
https://github.com/alvyxaz/barebones-masterserver/issues
(you can also ask questions there too)

Have Fun!