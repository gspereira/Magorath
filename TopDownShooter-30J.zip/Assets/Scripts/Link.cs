﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class Link : MonoBehaviour {

    public GameObject MainCamera;
    [SerializeField]
    public Slider HPSlider;
    [SerializeField]
    public Slider SPSlider;

    [SerializeField]
    public Slider SpecialSlider;
    [SerializeField]
    public Slider Special2Slider;

    public GameObject DeadScreen;

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
